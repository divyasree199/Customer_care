package com.divya.java_customer_assignment.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.divya.java_customer_assignment.entity.Customer;
import com.divya.java_customer_assignment.exceptions.CustomerNotFoundException;
import com.divya.java_customer_assignment.model.CustomerDTO;
import com.divya.java_customer_assignment.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository customerRepository;
	
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Override
	public CustomerDTO createCustomer(CustomerDTO customerDTO) {
		Customer customer = customerRepository.saveAndFlush(modelMapper.map(customerDTO, Customer.class));
		return modelMapper.map(customer, CustomerDTO.class);
	}


	@Override
	public CustomerDTO getCustomer(Integer id) {

		Optional<Customer> customer = customerRepository.findById(id);
		if (customer.isPresent()) {
			return modelMapper.map(customer.get(), CustomerDTO.class);
		}
		return null;
	}

	@Override
	public String deleteCustomer(Integer id) {
		customerRepository.deleteById(id);
		return "Product deleted successfully";
	}

	@Override
	public CustomerDTO updateCustomer(Integer id, CustomerDTO customerDTO) throws CustomerNotFoundException {
		Optional<Customer> optionalCustomer = customerRepository.findById(id);
		Customer customer = null;
		if (optionalCustomer.isPresent()) {
			 customer = optionalCustomer.get();
			customer.setAddress(customerDTO.getAddress());
			customer.setCity(customerDTO.getCity());
			customer.setEmail(customerDTO.getEmail());
			customer.setFirstName(customerDTO.getFirstName());
			customer.setLastName(customerDTO.getLastName());
			customer.setPhone(customerDTO.getPhone());
			customer.setState(customerDTO.getState());
			customerRepository.save(customer);

		} else {
			throw new CustomerNotFoundException("customer does not exist for this id ");
		}
		return modelMapper.map(customer, CustomerDTO.class);
	}

	@Override
	public List<CustomerDTO> getCustomers(int pageNo, int pageSize, String sortBy, String sortDirection) {
	      Sort sort = Sort.by(Sort.Direction.fromString(sortDirection), sortBy);
	      Pageable pageable = PageRequest.of(pageNo, pageSize, sort);

			Page<Customer>  customersPage =customerRepository.findAll(pageable);
			List<Customer> customers = customersPage.getContent();
			List<CustomerDTO> customerDTOs = new ArrayList<>(customers.size());
			for (Customer customer : customers) {
				customerDTOs.add(modelMapper.map(customer, CustomerDTO.class));
			}
	
			return customerDTOs;

	}

}
