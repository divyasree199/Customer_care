package com.divya.java_customer_assignment.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.divya.java_customer_assignment.exceptions.CustomerNotFoundException;
import com.divya.java_customer_assignment.model.CustomerDTO;
import com.divya.java_customer_assignment.service.CustomerService;



@RestController
@RequestMapping("/customers")
public class CustomerController {
	@Autowired
	CustomerService customerService;
	
	
	@PostMapping
	public ResponseEntity<CustomerDTO> createCustomer(@RequestBody CustomerDTO customerDTO) {

		return ResponseEntity.status(HttpStatus.CREATED).body(customerService.createCustomer(customerDTO));
	}

	@PutMapping(value = "/{customerId}")
	public ResponseEntity<CustomerDTO> updateCustomer(@PathVariable("customerId") int customerId,
			@RequestBody CustomerDTO customerDTO) throws CustomerNotFoundException {
		return ResponseEntity.status(HttpStatus.OK).body(customerService.updateCustomer(customerId, customerDTO));
	}

	  @GetMapping("/customers_list")
	  public List<CustomerDTO> findAll(
	          @RequestParam(defaultValue = "0") int pageNo,
	          @RequestParam(defaultValue = "5") int pageSize,
	          @RequestParam(defaultValue = "id") String sortBy,
	          @RequestParam(defaultValue = "ASC") String sortDirection) {
	      return customerService.getCustomers(pageNo, pageSize, sortBy, sortDirection);
	      

	  }

	@GetMapping(value = "/{customerId}")
	public CustomerDTO getCustomer(@PathVariable("customerId") int customerId) {
		return customerService.getCustomer(customerId);
	}
	
	@DeleteMapping(value = "/{customerId}")
	public String deleteCustomer(@PathVariable("customerId") int customerId) {
		return customerService.deleteCustomer(customerId);
	}

}
