package com.divya.java_customer_assignment.service;

import java.util.List;

import com.divya.java_customer_assignment.exceptions.CustomerNotFoundException;
import com.divya.java_customer_assignment.model.CustomerDTO;

public interface CustomerService {

	public CustomerDTO createCustomer(CustomerDTO customerDTO);
		
	public CustomerDTO getCustomer(Integer id);
	
	public String deleteCustomer(Integer id);
	
	public CustomerDTO updateCustomer(Integer id, CustomerDTO customerDTO) throws CustomerNotFoundException;

	public List<CustomerDTO> getCustomers(int pageNo, int pageSize, String sortBy, String sortDirection);
}
