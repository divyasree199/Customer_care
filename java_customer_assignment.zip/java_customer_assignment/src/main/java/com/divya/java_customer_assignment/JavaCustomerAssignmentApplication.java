package com.divya.java_customer_assignment;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class JavaCustomerAssignmentApplication {

	// Bean that helps mapping a DTO to an entity and vice versa
	@Bean
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}
	
	public static void main(String[] args) {
		SpringApplication.run(JavaCustomerAssignmentApplication.class, args);
	}

}
