package com.divya.java_customer_assignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaCustomerAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
